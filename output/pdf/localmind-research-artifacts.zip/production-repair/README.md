# Exact local production-repair snapshots

Copy the included relative paths into a separate checkout of the recorded Linux
base commit ddbbbb7be35a83c6ebc32706bb0aaf41ff379ff8. These are locally applied,
uncommitted snapshots. They are not claimed to exist in that historical commit.
The Windows copy contains byte-identical repaired inference code and context tests.

Read research/evaluation/README.md before reproducing. The supplied verifier
records the actual observed run and refuses to overwrite it; select a new run ID
and rebuild the primary index before a new execution. Runtime, models, original
application dependencies and the full application checkout are not bundled here.
