"""Post-repair replay using production Ollama.chat and its real outgoing payloads.

No fitter substitution, model change, prompt change or frozen-output overwrite.
The existing benchmark supplies the deterministic question order and scoring.
"""
from pathlib import Path
import asyncio
import copy
import hashlib
import json
import sqlite3
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
HERE = ROOT / 'research/evaluation'
sys.path[:0] = [str(ROOT), str(HERE)]
import run_benchmark as primary

RUN = '2026-10-17-production-context-fix-v1'
OUT = HERE / 'results' / RUN

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def frozen_hashes():
    return {str(p.relative_to(ROOT)): digest(p)
            for name in ['2026-10-17-main-v1', '2026-10-17-context-diagnostic-v1']
            for p in (HERE / 'results' / name).rglob('*') if p.is_file()}

class AuditedOllama(primary.MeasuredOllama):
    """Observe after production fitting; never edit the request."""
    def _request(self, method, endpoint, payload=None, timeout=180):
        audit = None
        if endpoint == '/api/chat':
            messages, tools = payload['messages'], payload.get('tools')
            def encoded(value):
                return len(json.dumps(value, ensure_ascii=False,
                                      separators=(',', ':')).encode('utf-8'))
            cost = sum(encoded(item) + 24 for item in messages) + (encoded(tools) if tools else 0)
            budget = self.settings.context_size - min(1536, self.settings.context_size // 3) - 256
            assert cost <= budget, (cost, budget)
            references = [item for item in messages if item.get('role') == 'tool' or
                          (item.get('role') == 'system' and item.get('content', '').startswith(
                              'UNTRUSTED DOCUMENT EVIDENCE:'))]
            audit = {'serialized_cost': cost, 'budget': budget,
                     'reference_messages': len(references),
                     'reference_characters': sum(len(item.get('content', '')) for item in references),
                     'fitted_messages': copy.deepcopy(messages)}
        try:
            return super()._request(method, endpoint, payload, timeout)
        finally:
            if audit is not None and self.calls:
                self.calls[-1]['production_context'] = audit

async def main():
    before = frozen_hashes()
    source = ROOT / '.runtime/research/index/2026-10-17-main-v1/memory.sqlite3'
    target = ROOT / '.runtime/research/index' / RUN / 'memory.sqlite3'
    assert not target.exists() and not OUT.exists(), 'Use a new run ID instead of overwriting evidence.'
    target.parent.mkdir(parents=True)
    with sqlite3.connect(source.as_uri() + '?mode=ro', uri=True) as reader, sqlite3.connect(target) as writer:
        reader.backup(writer)
    primary.MeasuredOllama = AuditedOllama
    sys.argv = [str(HERE / 'run_benchmark.py'), '--run-id', RUN,
                '--phase', 'generation', '--ollama-url', 'http://127.0.0.1:11438']
    await primary.main()
    assert before == frozen_hashes(), 'Historical study artifacts must not change.'
    rows = primary.load_jsonl(OUT / 'generation.jsonl')
    assert len(rows) == 64 and all(not row['error'] for row in rows)
    assert all(row['model_calls'][0]['production_context']['reference_messages'] > 0 for row in rows)
    result = {'date': '2026-10-17', 'run_id': RUN,
              'scope': 'Production repair replay on reused synthetic questions; not held-out confirmation.',
              'source_sha256': {str(p.relative_to(ROOT)): digest(p) for p in
                                [ROOT / 'copilot/ollama.py', ROOT / 'tests/test_context.py', Path(__file__)]},
              'fitter_substitution': False, 'frozen_results_unchanged': True,
              'requests_with_initial_reference': 64, 'requests': 64,
              'all_model_calls_within_serialized_budget': True,
              'functional_validation': {'linux': {'passed': 62},
                                        'windows_copy_on_linux': {'passed': 99, 'native_windows_skipped': 6}},
              'generation': primary.summarize(OUT, json.loads((HERE / 'dataset.json').read_text()))['generation']}
    primary.write_json(OUT / 'repair-verification.json', result)
    report = ROOT / 'output/verification'
    report.mkdir(parents=True, exist_ok=True)
    primary.write_json(report / 'context-fitting-fix.json', result)
    print('REPAIR_VERIFICATION', json.dumps({k: v for k, v in result.items() if k != 'generation'}), flush=True)

if __name__ == '__main__':
    asyncio.run(main())
