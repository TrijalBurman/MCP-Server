"""Local Knowledge Copilot."""
